public class Computer extends NetworkDevice {

    protected static String IPAddress;
    protected static NetworkDevice connectedTo;

    public Computer(String ID, String manufacturer, int linkSpeed, String IPAddress) {
        super(ID, manufacturer, linkSpeed);
        this.IPAddress = IPAddress;
    }

    public String getIPAddress() {
        return IPAddress;
    }

    public void setiPAddress(String IPAddress) {
        this.IPAddress = IPAddress;
    }

    public NetworkDevice getConnectedTo() {
        return connectedTo;
    }

    public void setConnectedTo(NetworkDevice connectedTo) {
        this.connectedTo = connectedTo;
    }

    @Override
    public String toString() {
        return "\n(Computer) " + "|" + super.toString() + "|" +
                " Connected to: " + connectedTo;
    }
}
