
import java.util.HashMap;
import java.util.Objects;

public class Switch extends NetworkDevice {

    private Integer numberOfPorts;
    private HashMap<String, NetworkDevice> myMap = new HashMap<>();


    public Switch(String ID, String manufacturer, Integer linkSpeed, Integer numberOfPorts) {
        super(ID, manufacturer, linkSpeed);
        this.numberOfPorts = numberOfPorts;
    }

    public Integer getNumberOfPorts() {
        return numberOfPorts;
    }

    public void setNumberOfPorts(Integer numberOfPorts) {
        this.numberOfPorts = numberOfPorts;
    }

    //TODO Add connectedTo and create hashmap link
    public void addRoute() {
    myMap.put(Computer.IPAddress, Computer.connectedTo);
    }

    @Override
    public String toString() {
        return "\n(Switch) " + "|"
                + super.toString() + "|"
                + "Number of Ports: " + numberOfPorts;   }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Switch)) return false;
        Switch aSwitch = (Switch) o;
        return Objects.equals(getID(), aSwitch.getID()) && Objects.equals(myMap, aSwitch.myMap);
    }

    @Override
    public int hashCode() {
        return Objects.hash(getID(), myMap);
    }

    public HashMap<String, Integer> addRoute(HashMap<String, Integer> myMap) {
        myMap.put(Computer.IPAddress, getID().hashCode());
        return myMap;
    }

}