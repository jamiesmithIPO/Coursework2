import java.util.ArrayList;

public class Main {

    public static ArrayList<NetworkDevice> networkDevices = new ArrayList<>();

    public static void getNetworkDeviceById() {
        for (NetworkDevice networkDevice : networkDevices) {
            if (Computer.connectedTo != null) {
                System.out.println(networkDevice);
            } else {
                System.out.println("Not connected");
            }
        }
    }

    public static void printNetworkDevices(){
        for (NetworkDevice networkDevice : networkDevices) {
            System.out.println(networkDevice);
        }
    }
    public static void main(String[] args) {

        Computer computer1 = new Computer("1","Dell", 100, "192.168.1.1");
        Switch switch1 = new Switch("1", "Cisco", 100, 12);
        networkDevices.add(computer1);
        networkDevices.add(switch1);
        printNetworkDevices();
    }
}
