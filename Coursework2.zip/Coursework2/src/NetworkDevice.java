
abstract class NetworkDevice {


    protected static String ID;
    private String manufacturer;
    private Integer linkSpeed;


    public NetworkDevice(String ID, String manufacturer, Integer linkSpeed) {
        this.ID = ID;
        this.manufacturer = manufacturer;
        this.linkSpeed = linkSpeed;
    }

    public NetworkDevice() {

    }

    public String getID() {
        return this.ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public Integer getLinkSpeed() {
        return linkSpeed;
    }

    public void setLinkSpeed(Integer linkSpeed) {
        this.linkSpeed = linkSpeed;
    }

    @Override
    public String toString() {
        return " Manufacturer: " +  manufacturer + "|" +
                " ID: " + "("+ ID +")"  + "|" +
                " LinkSpeed: " + linkSpeed;
    }
}